import assert from 'node:assert/strict'
import test from 'node:test'
import {
  addDevice,
  addGroup,
  addMaintenance,
  addWeeks,
  copyMaintenance,
  createSeedDb,
  deleteDevice,
  deleteGroup,
  deviceStatus,
  dueLevel,
  filterMaintenanceRows,
  leadingOpenTask,
  markPerformed,
  moveDevice,
  moveMaintenance,
  maintenanceEditError,
  maintenanceEditFields,
  nextFreeDeviceNumber,
  completedMaintenanceRows,
  maintenanceOverviewRows,
  openMaintenances,
  performedActionLabel,
  renameGroup,
  sortCompletedMaintenances,
  sortDevices,
  sortMaintenanceOverview,
  sortedDocumentation,
  todayISO,
  updateMaintenanceDetail,
} from '../src/model.js'

const today = '2026-10-01'

test('color rules follow the sketch', () => {
  assert.equal(dueLevel('2026-09-30', today), 'overdue')
  assert.equal(dueLevel('2026-10-01', today), 'soon')
  assert.equal(dueLevel('2026-10-08', today), 'soon')
  assert.equal(dueLevel('2026-10-09', today), 'ok')
})

test('a device takes the most urgent maintenance', () => {
  const db = createSeedDb(new Date(2026, 9, 1))
  const flipper = deviceStatus('d-flipper', db.maintenances, today)
  assert.equal(flipper.level, 'overdue')
  assert.equal(deviceStatus('d-dance', db.maintenances, today).level, 'soon')
  assert.equal(deviceStatus('d-race', db.maintenances, today).level, 'ok')
})

test('Durchgeführt sets erledigt, creates an open copy, and leaves erledigt out of the open list', () => {
  const db = createSeedDb(new Date(2026, 9, 1))
  const user = { name: 'Anna Berger', role: 'standard' }
  const original = db.maintenances.find((item) => item.id === 'm-klima')
  const result = markPerformed(db, 'm-klima', user, today)
  assert.equal(result.ok, true)
  const updated = result.db.maintenances.find((item) => item.id === 'm-klima')
  assert.equal(updated.status, 'erledigt')
  assert.equal(updated.performedBy, 'Anna Berger')
  assert.equal(updated.completedAt, today)
  assert.equal(updated.dueDate, original.dueDate)
  assert.equal(updated.intervalWeeks, original.intervalWeeks)
  assert.equal(updated.description, original.description)
  assert.equal(updated.detail, original.detail)
  assert.equal(updated.createdBy, original.createdBy)
  assert.equal(result.db.documentation.length, db.documentation.length)
  assert.equal(result.db.nextDocNumber, db.nextDocNumber)
  assert.equal(result.db.maintenances.length, db.maintenances.length + 1)

  const open = openMaintenances(result.db.maintenances, 'd-klima')
  assert.equal(open.length, 1)
  assert.equal(open.some((item) => item.status === 'erledigt'), false)
  const copy = open[0]
  assert.notEqual(copy.id, original.id)
  assert.equal(copy.status, 'offen')
  assert.equal(copy.performedBy, '')
  assert.equal(copy.completedAt, null)
  assert.equal(copy.createdBy, 'Anna Berger')
  assert.equal(copy.deviceId, 'd-klima')
  assert.equal(copy.dueDate, addWeeks(original.dueDate, original.intervalWeeks))
  assert.equal(copy.intervalWeeks, original.intervalWeeks)
  assert.equal(copy.description, original.description)
  assert.equal(copy.detail, original.detail)
  assert.deepEqual(
    sortedDocumentation(result.db.maintenances, 'd-klima').map((item) => item.id),
    ['m-klima'],
  )
  assert.equal(deviceStatus('d-klima', result.db.maintenances, today).dueDate, copy.dueDate)
  const again = markPerformed(result.db, 'm-klima', user, today)
  assert.equal(again.ok, false)
})

test('super-user maintenance and device changes validate input', () => {
  const db = createSeedDb(new Date(2026, 9, 1))
  const missing = addMaintenance(db, {
    deviceId: 'd-vr',
    dueDate: '',
    intervalWeeks: 0,
    description: '   ',
  })
  assert.equal(missing.ok, false)

  const added = addMaintenance(db, {
    deviceId: 'd-vr',
    dueDate: '2026-11-01',
    intervalWeeks: 2,
    description: 'Kabel prüfen',
    createdBy: 'Jonas Keller',
  })
  assert.equal(added.ok, true)
  const created = added.db.maintenances.at(-1)
  assert.equal(created.description, 'Kabel prüfen')
  assert.equal(created.status, 'offen')
  assert.equal(created.createdBy, 'Jonas Keller')
  assert.equal(created.performedBy, '')
  assert.equal(created.completedAt, null)

  const device = addDevice(db, 'g-haus', 'Kasse', 6)
  assert.equal(device.ok, true)
  assert.equal(device.db.devices.at(-1).number, 6)
  const doneKlima = {
    ...device.db,
    maintenances: device.db.maintenances.map((item) =>
      item.deviceId === 'd-klima' ? { ...item, status: 'erledigt' } : item,
    ),
  }
  const removed = deleteDevice(doneKlima, 'd-klima')
  assert.equal(removed.ok, true)
  assert.equal(removed.db.devices.some((item) => item.id === 'd-klima'), false)
  assert.equal(removed.db.maintenances.some((item) => item.deviceId === 'd-klima'), false)
  assert.equal(nextFreeDeviceNumber(removed.db.devices), 5)
})

test('next free device number is the smallest missing positive integer', () => {
  assert.equal(nextFreeDeviceNumber([]), 1)
  assert.equal(nextFreeDeviceNumber([{ number: 1 }, { number: 2 }, { number: 4 }]), 3)
  const db = createSeedDb(new Date(2026, 9, 1))
  assert.equal(nextFreeDeviceNumber(db.devices), 6)
})

test('a duplicate device number is rejected', () => {
  const db = createSeedDb(new Date(2026, 9, 1))
  const taken = addDevice(db, 'g-haus', 'Kasse', 1)
  assert.equal(taken.ok, false)
  assert.equal(taken.error, 'Nummer schon vergeben.')
  assert.equal(db.devices.some((device) => device.name === 'Kasse'), false)
  const gap = addDevice(db, 'g-haus', 'Kasse', 3)
  assert.equal(gap.ok, false)
  assert.equal(gap.error, 'Nummer schon vergeben.')
})

test('documentation lists only completed maintenances, newest completion first', () => {
  const maintenances = [
    { id: 'old', deviceId: 'd', status: 'erledigt', completedAt: null, createdAt: '2026-10-01T08:00:00.000Z' },
    { id: 'done-early', deviceId: 'd', status: 'erledigt', completedAt: '2026-10-03', createdAt: '2026-09-01T08:00:00.000Z' },
    { id: 'open-later', deviceId: 'd', status: 'offen', completedAt: null, createdAt: '2026-10-04T10:00:00.000Z' },
    { id: 'done-later', deviceId: 'd', status: 'erledigt', completedAt: '2026-10-04', createdAt: '2026-08-01T08:00:00.000Z' },
    { id: 'other', deviceId: 'other', status: 'erledigt', completedAt: '2026-12-01', createdAt: '2026-01-01T00:00:00.000Z' },
  ]
  assert.deepEqual(
    sortedDocumentation(maintenances, 'd').map((item) => item.id),
    ['done-later', 'done-early', 'old'],
  )
  assert.deepEqual(openMaintenances(maintenances, 'd').map((item) => item.id), ['open-later'])
})

test('completing a maintenance lists the successor as open and the finished row only as documentation', () => {
  const db = createSeedDb(new Date(2026, 9, 1))
  const prepared = {
    ...db,
    maintenances: db.maintenances.map((item) =>
      item.id === 'm-klima' ? { ...item, dueDate: '2026-10-30', intervalWeeks: 4 } : item,
    ),
  }
  const original = prepared.maintenances.find((item) => item.id === 'm-klima')
  assert.equal(performedActionLabel({ name: 'Anna Berger', username: 'anna' }), 'Durchgeführt Anna Berger')
  assert.equal(performedActionLabel({ name: '  ', username: 'anna' }), 'Durchgeführt anna')
  assert.equal(maintenanceOverviewRows(prepared).some((row) => row.status !== 'offen'), false)
  assert.equal(completedMaintenanceRows(prepared).length, 0)

  const done = markPerformed(prepared, 'm-klima', { name: 'Anna Berger', username: 'anna' }, today)
  assert.equal(done.ok, true)
  assert.equal(done.db.documentation.length, prepared.documentation.length)

  const openRows = maintenanceOverviewRows(done.db)
  assert.equal(openRows.every((row) => row.status === 'offen'), true)
  assert.equal(openRows.some((row) => row.maintenanceId === 'm-klima'), false)
  assert.equal(openRows.some((row) => row.id.startsWith('documentation:')), false)
  const successor = openRows.find((row) => row.description === original.description && row.deviceNumber === 5)
  assert.equal(successor.statusLabel, 'offen')
  assert.equal(successor.performedBy, '')
  assert.equal(successor.completedAt, '')
  assert.equal(successor.createdBy, 'Anna Berger')
  assert.equal(successor.groupName, 'Haustechnik')
  assert.equal(successor.dueDate, addWeeks(original.dueDate, original.intervalWeeks))
  assert.equal(successor.dueDate, '2026-11-27')
  assert.equal(successor.intervalWeeks, 4)
  assert.equal(successor.detail, original.detail)

  const completed = completedMaintenanceRows(done.db)
  assert.equal(completed.length, 1)
  assert.equal(completed[0].maintenanceId, 'm-klima')
  assert.equal(completed[0].status, 'erledigt')
  assert.equal(completed[0].statusLabel, 'erledigt')
  assert.equal(completed[0].performedBy, 'Anna Berger')
  assert.equal(completed[0].completedAt, today)
  assert.equal(completed[0].dueDate, '2026-10-30')
  assert.equal(completed[0].intervalWeeks, 4)
  assert.equal(completed[0].description, original.description)
  assert.equal(completed[0].detail, original.detail)
  assert.equal(completed[0].createdBy, 'Jonas Keller')
  assert.equal(completed[0].groupName, 'Haustechnik')
  assert.equal(completed[0].deviceNumber, 5)
  assert.equal(completed.some((row) => row.id.startsWith('documentation:')), false)
})

test('completed maintenances sort by completion date, falling back to the due date', () => {
  const rows = [
    { id: 'a-old', groupName: 'Arcade', deviceName: 'Alpha', completedAt: '2026-09-01', dueDate: '2026-12-01', description: 'Alt' },
    { id: 'a-new', groupName: 'Arcade', deviceName: 'Beta', completedAt: '2026-10-15', dueDate: '2026-01-01', description: 'Neu' },
    { id: 'a-due-only', groupName: 'Arcade', deviceName: 'Gamma', completedAt: '', dueDate: '2026-10-20', description: 'Fällig' },
    { id: 'h-mid', groupName: 'Haus', deviceName: 'Klima', completedAt: '2026-10-02', dueDate: '2026-09-20', description: 'Filter' },
    { id: 'v-none', groupName: 'VR', deviceName: 'Quest', completedAt: '', dueDate: '', description: 'Linsen' },
    { id: 'h-same', groupName: 'Haus', deviceName: 'Heizung', completedAt: '2026-10-02', dueDate: '2026-11-01', description: 'Prüfung' },
  ]
  assert.deepEqual(
    sortCompletedMaintenances(rows).map((row) => row.id),
    ['a-due-only', 'a-new', 'h-same', 'h-mid', 'a-old', 'v-none'],
  )
  assert.deepEqual(
    sortCompletedMaintenances(rows, 'date').map((row) => row.id),
    sortCompletedMaintenances(rows, 'other').map((row) => row.id),
  )
  assert.deepEqual(
    sortCompletedMaintenances(rows, 'group').map((row) => row.id),
    ['a-due-only', 'a-new', 'a-old', 'h-same', 'h-mid', 'v-none'],
  )
  assert.deepEqual(
    sortCompletedMaintenances(rows, 'group').map((row) => row.groupName),
    ['Arcade', 'Arcade', 'Arcade', 'Haus', 'Haus', 'VR'],
  )
})

test('maintenance overview sorts by due date, then by group and device', () => {
  const rows = [
    { id: 'vr-late', groupName: 'VR', deviceName: 'Quest', dueDate: '2026-11-01', description: 'Linsen' },
    { id: 'arcade-overdue-b', groupName: 'Arcade', deviceName: 'Beta', dueDate: '2026-09-01', description: 'B' },
    { id: 'arcade-overdue-a', groupName: 'Arcade', deviceName: 'Alpha', dueDate: '2026-09-01', description: 'A' },
    { id: 'haus-mid', groupName: 'Haus', deviceName: 'Klima', dueDate: '2026-10-01', description: 'Filter' },
    { id: 'arcade-doc', groupName: 'Arcade', deviceName: 'Alpha', dueDate: '', description: 'Protokoll' },
    { id: 'haus-nodue', groupName: 'Haus', deviceName: 'Heizung', dueDate: '', description: 'Alt' },
  ]
  assert.deepEqual(
    sortMaintenanceOverview(rows).map((row) => row.id),
    ['arcade-overdue-a', 'arcade-overdue-b', 'haus-mid', 'vr-late', 'arcade-doc', 'haus-nodue'],
  )
  assert.deepEqual(
    sortMaintenanceOverview(rows, 'due').map((row) => row.id),
    ['arcade-overdue-a', 'arcade-overdue-b', 'haus-mid', 'vr-late', 'arcade-doc', 'haus-nodue'],
  )
  assert.deepEqual(
    sortMaintenanceOverview(rows, 'group').map((row) => row.id),
    ['arcade-overdue-a', 'arcade-overdue-b', 'arcade-doc', 'haus-mid', 'haus-nodue', 'vr-late'],
  )
  assert.deepEqual(
    sortMaintenanceOverview(rows, 'due').map((row) => row.id),
    sortMaintenanceOverview(rows, 'other').map((row) => row.id),
  )
})

test('seeded maintenances sort overdue first, and groups sort alphabetically', () => {
  const db = createSeedDb(new Date(2026, 9, 1))
  const byDue = sortMaintenanceOverview(maintenanceOverviewRows(db), 'due')
  assert.deepEqual(
    byDue.map((row) => row.id),
    [
      'maintenance:m-flipper-oil',
      'maintenance:m-klima',
      'maintenance:m-dance',
      'maintenance:m-vr',
      'maintenance:m-flipper-clean',
      'maintenance:m-race',
    ],
  )
  const byGroup = sortMaintenanceOverview(maintenanceOverviewRows(db), 'group')
  assert.deepEqual(
    byGroup.map((row) => row.groupName),
    [
      'Arcade-Automaten',
      'Arcade-Automaten',
      'Arcade-Automaten',
      'Arcade-Automaten',
      'Haustechnik',
      'VR & Konsolen',
    ],
  )
  assert.deepEqual(
    byGroup.filter((row) => row.groupName === 'Arcade-Automaten').map((row) => row.id),
    [
      'maintenance:m-flipper-oil',
      'maintenance:m-dance',
      'maintenance:m-flipper-clean',
      'maintenance:m-race',
    ],
  )
  assert.equal(maintenanceOverviewRows(db).some((row) => row.id.startsWith('documentation:')), false)
  assert.equal(completedMaintenanceRows(db).length, 0)
})

test('a maintenance stores Wartungsbeschrieb separately from the short description', () => {
  const db = createSeedDb(new Date(2026, 9, 1))
  const seeded = db.maintenances.find((item) => item.id === 'm-flipper-oil')
  assert.equal(seeded.detail.includes('Schrank A'), true)
  assert.notEqual(seeded.detail, seeded.description)

  const added = addMaintenance(db, {
    deviceId: 'd-vr',
    dueDate: '2026-11-01',
    intervalWeeks: 2,
    description: 'Kabel prüfen',
    detail: 'Stecker lösen und den Kabelzug an der Rückseite prüfen.',
    createdBy: 'Jonas Keller',
  })
  assert.equal(added.ok, true)
  const created = added.db.maintenances.at(-1)
  assert.equal(created.detail, 'Stecker lösen und den Kabelzug an der Rückseite prüfen.')
  assert.notEqual(created.detail, created.description)

  const edited = updateMaintenanceDetail(added.db, created.id, 'Neuer Beschrieb mit Link.')
  assert.equal(edited.ok, true)
  assert.equal(edited.db.maintenances.find((item) => item.id === created.id).detail, 'Neuer Beschrieb mit Link.')
  assert.equal(edited.db.maintenances.find((item) => item.id === created.id).description, 'Kabel prüfen')

  const performed = markPerformed(edited.db, created.id, { name: 'Anna Berger' }, today)
  assert.equal(performed.ok, true)
  assert.equal(
    performed.db.maintenances.find((item) => item.id === created.id).detail,
    'Neuer Beschrieb mit Link.',
  )
  const blocked = updateMaintenanceDetail(performed.db, created.id, 'Darf nicht mehr geändert werden.')
  assert.equal(blocked.ok, false)
  assert.equal(
    performed.db.maintenances.find((item) => item.id === created.id).detail,
    'Neuer Beschrieb mit Link.',
  )
  const successor = openMaintenances(performed.db.maintenances, 'd-vr').find((item) => item.description === 'Kabel prüfen')
  assert.equal(successor.detail, 'Neuer Beschrieb mit Link.')
  assert.equal(successor.status, 'offen')

  const empty = addMaintenance(db, {
    deviceId: 'd-vr',
    dueDate: '2026-11-02',
    intervalWeeks: 2,
    description: 'Kurz',
    createdBy: 'Jonas Keller',
  })
  assert.equal(empty.db.maintenances.at(-1).detail, '')
})

test('editing a maintenance validates the text fields and does not invent a completion date', () => {
  assert.equal(
    maintenanceEditError({ description: '   ', dueDate: '2026-12-01', intervalWeeks: 2, status: 'offen' }),
    'Bitte eine Wartungsbeschreibung angeben.',
  )
  assert.equal(
    maintenanceEditError({ description: 'Filter prüfen', dueDate: '', intervalWeeks: 2, status: 'offen' }),
    'Bitte ein Fälligkeitsdatum angeben.',
  )
  assert.equal(
    maintenanceEditError({ description: 'Filter prüfen', dueDate: '2026-12-01', intervalWeeks: 0, status: 'offen' }),
    'Das Intervall muss mindestens 1 Woche sein.',
  )
  const done = maintenanceEditFields({
    description: ' Filter prüfen ',
    dueDate: '2026-12-15',
    intervalWeeks: 6,
    detail: 'Neues Filterset.',
    createdBy: 'Mia Frei',
    status: 'erledigt',
    performedBy: 'Lea Sommer',
    completedAt: '2026-10-03',
  })
  assert.equal(done.description, 'Filter prüfen')
  assert.equal(done.detail, 'Neues Filterset.')
  assert.equal(done.createdBy, 'Mia Frei')
  assert.equal(done.performedBy, 'Lea Sommer')
  assert.equal(done.completedAt, '2026-10-03')
  assert.equal(done.status, 'erledigt')
  const open = maintenanceEditFields({ ...done, status: 'offen', completedAt: '' })
  assert.equal(open.status, 'offen')
  assert.equal(open.completedAt, null)
  assert.equal(open.performedBy, 'Lea Sommer')
})

test('device lists sort by urgency and then by name', () => {
  const devices = [
    { id: 'zulu', name: 'Zulu' },
    { id: 'alpha', name: 'Alpha' },
    { id: 'mitte', name: 'Mitte' },
    { id: 'bald', name: 'Bald' },
    { id: 'gruen', name: 'Grün' },
    { id: 'apfel', name: 'Apfel' },
    { id: 'ohne', name: 'ohne Gerät' },
    { id: 'zebra', name: 'Zebra' },
    { id: 'frueh', name: 'Früh' },
  ]
  const maintenances = [
    { id: '1', deviceId: 'zulu', dueDate: '2026-08-01', status: 'offen' },
    { id: '2', deviceId: 'alpha', dueDate: '2026-09-20', status: 'offen' },
    { id: '3', deviceId: 'mitte', dueDate: '2026-10-02', status: 'offen' },
    { id: '4', deviceId: 'bald', dueDate: '2026-10-08', status: 'offen' },
    { id: '5', deviceId: 'gruen', dueDate: '2026-11-01', status: 'offen' },
    { id: '6', deviceId: 'apfel', dueDate: '2026-12-01', status: 'offen' },
    { id: '7', deviceId: 'frueh', dueDate: '2026-12-20', status: 'offen' },
    { id: '8', deviceId: 'frueh', dueDate: '2026-09-01', status: 'offen' },
    { id: '9', deviceId: 'zebra', dueDate: '2026-01-01', status: 'erledigt' },
  ]
  assert.deepEqual(
    sortDevices(devices, maintenances, today, 'due').map((device) => device.id),
    ['alpha', 'frueh', 'zulu', 'bald', 'mitte', 'apfel', 'gruen', 'ohne', 'zebra'],
  )
  assert.deepEqual(
    sortDevices(devices, maintenances, today).map((device) => device.name),
    ['Alpha', 'Früh', 'Zulu', 'Bald', 'Mitte', 'Apfel', 'Grün', 'ohne Gerät', 'Zebra'],
  )
  const byName = sortDevices(devices, maintenances, today, 'name-asc').map((device) => device.id)
  assert.deepEqual(byName, ['alpha', 'apfel', 'bald', 'frueh', 'gruen', 'mitte', 'ohne', 'zebra', 'zulu'])
  assert.deepEqual(
    sortDevices(devices, maintenances, today, 'name-desc').map((device) => device.id),
    byName.slice().reverse(),
  )
  assert.deepEqual(
    sortDevices(
      [{ id: 'b', name: 'beta' }, { id: 'a', name: 'Alpha' }],
      [],
      today,
      'name-asc',
    ).map((device) => device.id),
    ['a', 'b'],
  )
  assert.deepEqual(devices.map((device) => device.id)[0], 'zulu')
})

test('device lists sort by number ascending and descending', () => {
  const devices = [
    { id: 'c', name: 'C', number: 12 },
    { id: 'a', name: 'A', number: 2 },
    { id: 'b', name: 'B', number: 2 },
    { id: 'd', name: 'D', number: 7 },
  ]
  assert.deepEqual(
    sortDevices(devices, [], today, 'number-asc').map((device) => device.id),
    ['a', 'b', 'd', 'c'],
  )
  assert.deepEqual(
    sortDevices(devices, [], today, 'number-desc').map((device) => device.id),
    ['c', 'd', 'a', 'b'],
  )
})

test('the next open due date is the completed due date plus the interval', () => {
  assert.equal(addWeeks('2026-10-30', 4), '2026-11-27')
  const db = createSeedDb(new Date(2026, 9, 1))
  const prepared = {
    ...db,
    maintenances: db.maintenances.map((item) =>
      item.id === 'm-klima' ? { ...item, dueDate: '2026-10-30', intervalWeeks: 4 } : item,
    ),
  }
  const result = markPerformed(prepared, 'm-klima', { name: 'Anna Berger' }, '2026-10-02')
  assert.equal(result.ok, true)
  const successor = openMaintenances(result.db.maintenances, 'd-klima')[0]
  assert.equal(successor.status, 'offen')
  assert.equal(successor.dueDate, '2026-11-27')
  assert.equal(successor.intervalWeeks, 4)
  const completed = result.db.maintenances.find((item) => item.id === 'm-klima')
  assert.equal(completed.status, 'erledigt')
  assert.equal(completed.dueDate, '2026-10-30')
})

test('rename group and move device keep the maintenance records', () => {
  const db = createSeedDb(new Date(2026, 9, 1))
  const renamed = renameGroup(db, 'g-arcade', '  Spielautomaten  ')
  assert.equal(renamed.ok, true)
  assert.equal(renamed.db.groups.find((group) => group.id === 'g-arcade').name, 'Spielautomaten')
  assert.equal(renamed.db.maintenances.length, db.maintenances.length)
  assert.equal(renamed.db.devices.find((device) => device.id === 'd-flipper').groupId, 'g-arcade')
  assert.equal(renameGroup(db, 'g-arcade', '   ').ok, false)
  assert.equal(renameGroup(db, 'missing', 'Lager').ok, false)

  const moved = moveDevice(renamed.db, 'd-flipper', 'g-haus')
  assert.equal(moved.ok, true)
  assert.equal(moved.db.devices.find((device) => device.id === 'd-flipper').groupId, 'g-haus')
  assert.equal(moved.db.maintenances.filter((item) => item.deviceId === 'd-flipper').length, 2)
  assert.equal(moved.db.maintenances.find((item) => item.id === 'm-flipper-oil').description, 'Mechanik ölen und Kugeln prüfen')
  assert.equal(moveDevice(db, 'missing', 'g-haus').ok, false)
  assert.equal(moveDevice(db, 'd-flipper', 'missing').ok, false)
  assert.equal(db.devices.find((device) => device.id === 'd-flipper').groupId, 'g-arcade')
})

test('move maintenance keeps completion state and leaves the source device', () => {
  const db = createSeedDb(new Date(2026, 9, 1))
  const done = markPerformed(db, 'm-klima', { name: 'Anna Berger' }, today)
  const moved = moveMaintenance(done.db, 'm-klima', 'd-vr')
  assert.equal(moved.ok, true)
  const item = moved.db.maintenances.find((entry) => entry.id === 'm-klima')
  assert.equal(item.deviceId, 'd-vr')
  assert.equal(item.status, 'erledigt')
  assert.equal(item.performedBy, 'Anna Berger')
  assert.equal(item.completedAt, today)
  assert.equal(item.dueDate, done.db.maintenances.find((entry) => entry.id === 'm-klima').dueDate)
  const successor = moved.db.maintenances.find((entry) => entry.deviceId === 'd-klima')
  assert.equal(successor.status, 'offen')
  assert.equal(successor.dueDate, addWeeks(item.dueDate, item.intervalWeeks))
  assert.equal(moved.db.maintenances.filter((entry) => entry.deviceId === 'd-klima' && entry.status === 'erledigt').length, 0)
  assert.equal(moveMaintenance(db, 'missing', 'd-vr').ok, false)
  assert.equal(moveMaintenance(db, 'm-klima', 'missing').ok, false)
})

test('copy maintenance is offen and does not copy performed-by', () => {
  const db = createSeedDb(new Date(2026, 9, 1))
  const done = markPerformed(db, 'm-flipper-oil', { name: 'Anna Berger' }, today)
  const source = done.db.maintenances.find((item) => item.id === 'm-flipper-oil')
  const copied = copyMaintenance(done.db, 'm-flipper-oil', 'd-dance', 'Jonas Keller', '2026-10-02T12:00:00.000Z')
  assert.equal(copied.ok, true)
  const copy = copied.db.maintenances.find((item) => item.createdAt === '2026-10-02T12:00:00.000Z')
  assert.equal(copy.status, 'offen')
  assert.equal(copy.performedBy, '')
  assert.equal(copy.completedAt, null)
  assert.equal(copy.createdBy, 'Jonas Keller')
  assert.equal(copy.deviceId, 'd-dance')
  assert.equal(copy.dueDate, source.dueDate)
  assert.equal(copy.intervalWeeks, source.intervalWeeks)
  assert.equal(copy.description, source.description)
  assert.equal(copy.detail, source.detail)
  assert.notEqual(copy.id, source.id)
  const still = copied.db.maintenances.find((item) => item.id === source.id)
  assert.equal(still.status, 'erledigt')
  assert.equal(still.performedBy, 'Anna Berger')
  assert.equal(still.deviceId, 'd-flipper')
  assert.equal(copied.db.maintenances.length, done.db.maintenances.length + 1)
  assert.equal(copyMaintenance(done.db, 'm-flipper-oil', 'd-dance', '   ').ok, false)
})

test('a repair is stored without an interval and completing it does not create a successor', () => {
  const db = createSeedDb(new Date(2026, 9, 1))
  const before = db.maintenances.length
  const added = addMaintenance(db, {
    deviceId: 'd-vr',
    dueDate: '2026-10-20',
    kind: 'reparatur',
    description: 'Display tauschen',
    detail: 'Neues Panel aus dem Lager.',
    createdBy: 'Jonas Keller',
  })
  assert.equal(added.ok, true)
  const created = added.db.maintenances.at(-1)
  assert.equal(created.kind, 'reparatur')
  assert.equal(created.intervalWeeks, null)
  assert.equal(created.status, 'offen')
  assert.equal(created.description, 'Display tauschen')
  assert.equal(created.detail, 'Neues Panel aus dem Lager.')
  assert.equal(added.db.maintenances.length, before + 1)

  const ignoredInterval = addMaintenance(db, {
    deviceId: 'd-vr',
    dueDate: '2026-10-21',
    kind: 'reparatur',
    intervalWeeks: 8,
    description: 'Joystick tauschen',
    createdBy: 'Jonas Keller',
  })
  assert.equal(ignoredInterval.ok, true)
  assert.equal(ignoredInterval.db.maintenances.at(-1).intervalWeeks, null)
  assert.equal(ignoredInterval.db.maintenances.at(-1).kind, 'reparatur')

  const needsInterval = addMaintenance(db, {
    deviceId: 'd-vr',
    dueDate: '2026-10-22',
    kind: 'wartung',
    description: 'Ohne Intervall',
    createdBy: 'Jonas Keller',
  })
  assert.equal(needsInterval.ok, false)
  assert.equal(needsInterval.error, 'Das Intervall muss mindestens 1 Woche sein.')
  assert.equal(
    maintenanceEditError({
      kind: 'reparatur',
      description: 'Display tauschen',
      dueDate: '2026-10-20',
      status: 'offen',
    }),
    null,
  )
  const edited = maintenanceEditFields({
    kind: 'reparatur',
    description: ' Display tauschen ',
    dueDate: '2026-10-20',
    intervalWeeks: 9,
    detail: 'Panel links.',
    createdBy: 'Jonas Keller',
    status: 'offen',
    performedBy: '',
    completedAt: '',
  })
  assert.equal(edited.kind, 'reparatur')
  assert.equal(edited.intervalWeeks, null)

  const done = markPerformed(added.db, created.id, { name: 'Anna Berger' }, today)
  assert.equal(done.ok, true)
  assert.equal(done.db.maintenances.length, added.db.maintenances.length)
  const finished = done.db.maintenances.find((item) => item.id === created.id)
  assert.equal(finished.status, 'erledigt')
  assert.equal(finished.performedBy, 'Anna Berger')
  assert.equal(finished.completedAt, today)
  assert.equal(finished.kind, 'reparatur')
  assert.equal(finished.intervalWeeks, null)
  assert.equal(finished.dueDate, '2026-10-20')
  assert.equal(
    done.db.maintenances.some((item) => item.id !== created.id && item.description === 'Display tauschen'),
    false,
  )
  assert.equal(openMaintenances(done.db.maintenances, 'd-vr').some((item) => item.id === created.id), false)
  assert.equal(
    completedMaintenanceRows(done.db).some((row) => row.maintenanceId === created.id && row.taskKind === 'reparatur' && row.intervalWeeks == null),
    true,
  )
  assert.equal(maintenanceOverviewRows(done.db).some((row) => row.maintenanceId === created.id), false)
  assert.deepEqual(
    sortedDocumentation(done.db.maintenances, 'd-vr').map((item) => item.id),
    [created.id],
  )

  const copied = copyMaintenance(added.db, created.id, 'd-dance', 'Jonas Keller', '2026-10-03T08:00:00.000Z')
  assert.equal(copied.ok, true)
  const copy = copied.db.maintenances.find((item) => item.createdAt === '2026-10-03T08:00:00.000Z')
  assert.equal(copy.kind, 'reparatur')
  assert.equal(copy.intervalWeeks, null)
  assert.equal(copy.status, 'offen')
})

test('kind and date sort places Wartung before Reparatur and then orders by date', () => {
  const devices = [
    { id: 'repair-only', name: 'Nur Reparatur', number: 1 },
    { id: 'both', name: 'Beides', number: 2 },
    { id: 'wartung-late', name: 'Späte Wartung', number: 3 },
    { id: 'none', name: 'Leer', number: 4 },
    { id: 'wartung-early', name: 'Frühe Wartung', number: 5 },
  ]
  const maintenances = [
    { id: 'r1', deviceId: 'repair-only', kind: 'reparatur', dueDate: '2026-08-01', status: 'offen' },
    { id: 'b-repair', deviceId: 'both', kind: 'reparatur', dueDate: '2026-07-01', status: 'offen' },
    { id: 'b-wart', deviceId: 'both', kind: 'wartung', dueDate: '2026-12-01', status: 'offen' },
    { id: 'w-late', deviceId: 'wartung-late', kind: 'wartung', dueDate: '2026-11-01', status: 'offen' },
    { id: 'w-early', deviceId: 'wartung-early', kind: 'wartung', dueDate: '2026-10-01', status: 'offen' },
    { id: 'w-early-repair', deviceId: 'wartung-early', kind: 'reparatur', dueDate: '2026-01-01', status: 'offen' },
  ]
  assert.equal(leadingOpenTask('both', maintenances).id, 'b-wart')
  assert.equal(leadingOpenTask('wartung-early', maintenances).id, 'w-early')
  assert.equal(leadingOpenTask('repair-only', maintenances).kind, 'reparatur')
  assert.equal(leadingOpenTask('none', maintenances), null)
  assert.deepEqual(
    sortDevices(devices, maintenances, today, 'kind').map((device) => device.id),
    ['wartung-early', 'wartung-late', 'both', 'repair-only', 'none'],
  )

  const list = [
    { id: 'rep-early', kind: 'reparatur', dueDate: '2026-09-01', status: 'offen', deviceId: 'd' },
    { id: 'wart-late', kind: 'wartung', dueDate: '2026-12-01', status: 'offen', deviceId: 'd' },
    { id: 'wart-early', kind: 'wartung', dueDate: '2026-10-02', status: 'offen', deviceId: 'd' },
    { id: 'rep-late', kind: 'reparatur', dueDate: '2026-11-01', status: 'offen', deviceId: 'd' },
  ]
  assert.deepEqual(
    openMaintenances(list, 'd', { sort: 'kind' }).map((item) => item.id),
    ['wart-early', 'wart-late', 'rep-early', 'rep-late'],
  )
  assert.deepEqual(
    openMaintenances(list, 'd', { sort: 'date' }).map((item) => item.id),
    ['rep-early', 'wart-early', 'rep-late', 'wart-late'],
  )
  assert.deepEqual(
    openMaintenances(list, 'd').map((item) => item.id),
    ['rep-early', 'wart-early', 'rep-late', 'wart-late'],
  )
  assert.deepEqual(
    openMaintenances(list, 'd', { filter: 'reparatur' }).map((item) => item.id),
    ['rep-early', 'rep-late'],
  )
  assert.deepEqual(
    openMaintenances(list, 'd', { filter: 'wartung', sort: 'kind' }).map((item) => item.id),
    ['wart-early', 'wart-late'],
  )

  const rows = [
    { id: 'r-late', taskKind: 'reparatur', dueDate: '2026-11-01', groupName: 'Haus', deviceName: 'B', description: 'R2' },
    { id: 'w-late', taskKind: 'wartung', dueDate: '2026-12-01', groupName: 'VR', deviceName: 'A', description: 'W2' },
    { id: 'r-early', taskKind: 'reparatur', dueDate: '2026-08-01', groupName: 'Arcade', deviceName: 'C', description: 'R1' },
    { id: 'w-early', taskKind: 'wartung', dueDate: '2026-09-01', groupName: 'Haus', deviceName: 'D', description: 'W1' },
  ]
  assert.deepEqual(
    sortMaintenanceOverview(rows, 'kind').map((row) => row.id),
    ['w-early', 'w-late', 'r-early', 'r-late'],
  )
  assert.deepEqual(
    filterMaintenanceRows(rows, 'reparatur').map((row) => row.id),
    ['r-late', 'r-early'],
  )
  assert.deepEqual(
    sortMaintenanceOverview(filterMaintenanceRows(rows, 'wartung'), 'kind').map((row) => row.id),
    ['w-early', 'w-late'],
  )
  const done = [
    { id: 'c-r-new', taskKind: 'reparatur', completedAt: '2026-10-20', dueDate: '2026-01-01', groupName: 'Haus', deviceName: 'A', description: 'Neu' },
    { id: 'c-w-old', taskKind: 'wartung', completedAt: '2026-09-01', dueDate: '2026-12-01', groupName: 'Arcade', deviceName: 'B', description: 'Alt' },
    { id: 'c-w-new', taskKind: 'wartung', completedAt: '2026-10-15', dueDate: '2026-01-01', groupName: 'VR', deviceName: 'C', description: 'Wartung' },
    { id: 'c-r-old', taskKind: 'reparatur', completedAt: '2026-08-01', dueDate: '2026-07-01', groupName: 'Haus', deviceName: 'D', description: 'Alt R' },
  ]
  assert.deepEqual(
    sortCompletedMaintenances(done, 'kind').map((row) => row.id),
    ['c-w-new', 'c-w-old', 'c-r-new', 'c-r-old'],
  )
  assert.deepEqual(
    sortCompletedMaintenances(filterMaintenanceRows(done, 'reparatur'), 'date').map((row) => row.id),
    ['c-r-new', 'c-r-old'],
  )
})

test('today uses the local calendar date', () => {
  assert.equal(todayISO(new Date(2026, 9, 1)), '2026-10-01')
})

test('a group can be deleted only when it has no devices', () => {
  const db = createSeedDb(new Date(2026, 9, 1))
  const blocked = deleteGroup(db, 'g-haus')
  assert.equal(blocked.ok, false)
  assert.equal(blocked.error, 'Die Gruppe kann nicht gelöscht werden, solange sie Geräte enthält.')
  assert.equal(db.groups.some((group) => group.id === 'g-haus'), true)
  assert.equal(db.devices.some((device) => device.groupId === 'g-haus'), true)

  const added = addGroup(db, 'Lager')
  assert.equal(added.ok, true)
  const empty = added.db.groups.find((group) => group.name === 'Lager')
  const removed = deleteGroup(added.db, empty.id)
  assert.equal(removed.ok, true)
  assert.equal(removed.db.groups.some((group) => group.id === empty.id), false)
  assert.equal(removed.db.devices.length, db.devices.length)
  assert.equal(removed.db.groups.some((group) => group.id === 'g-haus'), true)
})

test('a device can be deleted only when its open maintenance list is empty', () => {
  const db = createSeedDb(new Date(2026, 9, 1))
  const blocked = deleteDevice(db, 'd-klima')
  assert.equal(blocked.ok, false)
  assert.equal(blocked.error, 'Das Gerät kann nicht gelöscht werden, solange offene Wartungen vorhanden sind.')
  assert.equal(db.devices.some((device) => device.id === 'd-klima'), true)

  const doneOnly = {
    ...db,
    maintenances: db.maintenances.map((item) =>
      item.deviceId === 'd-klima'
        ? { ...item, status: 'erledigt', performedBy: 'Anna Berger', completedAt: '2026-10-01' }
        : item,
    ),
    documentation: [
      ...db.documentation,
      {
        id: 'doc-klima',
        deviceId: 'd-klima',
        maintenanceId: 'm-klima',
        date: '2026-10-01',
        number: 2,
        userName: 'Anna Berger',
        description: 'Filter wechseln',
      },
    ],
  }
  assert.equal(openMaintenances(doneOnly.maintenances, 'd-klima').length, 0)
  const removed = deleteDevice(doneOnly, 'd-klima')
  assert.equal(removed.ok, true)
  assert.equal(removed.db.devices.some((device) => device.id === 'd-klima'), false)
  assert.equal(removed.db.maintenances.some((item) => item.deviceId === 'd-klima'), false)
  assert.equal(removed.db.documentation.some((item) => item.deviceId === 'd-klima'), false)
  assert.equal(removed.db.documentation.some((item) => item.id === 'doc-1'), true)
  assert.equal(removed.db.devices.some((device) => device.id === 'd-flipper'), true)
})
